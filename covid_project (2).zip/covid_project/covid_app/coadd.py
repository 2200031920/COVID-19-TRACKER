from .models import Country


def set_country():
     # add the country name extra need to be entered
    l = []

    for i in l:
        Country.objects.create(
            country = i
        )
