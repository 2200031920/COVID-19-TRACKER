from django.apps import AppConfig


class CovidAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'covid_app'
